﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Android</title>
<link rel="stylesheet" type="text/css" href="data/login.css" media="screen" />
</head>
<body>
<div class="login">
<form method="post" action="api.php?method=allview">
  <input type="text" placeholder="username" id="username" name="login">  
  <input type="password" placeholder="password" id="password" name="pass">  
  <input type="submit" value="Sign In">
</form>
</div>
</body>	
</html>